package com.example.quiz_application;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {


    Button True,False;
    TextView q;

    ProgressBar pb;

    int total_previous_q=0;
    int total_previous_a=0;

    int counter=1;

    int correct_answers=0;
    int bgColor;

    public String[] Question;
    public int number_of_questions;
    int no_of_questions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Question = new String[]
                {
                        getString(R.string.q1),
                        getString(R.string.q2),
                        getString(R.string.q3),
                        getString(R.string.q4),
                        getString(R.string.q5),
                        getString(R.string.q6),
                        getString(R.string.q7),
                        getString(R.string.q8),
                        getString(R.string.q9),
                        getString(R.string.q10),
                };

        number_of_questions=Question.length;
        no_of_questions=number_of_questions;



        readfile();

        True =findViewById(R.id.b_true);
        False=findViewById(R.id.b_false);
        q=findViewById(R.id.tv_question);
        pb=findViewById(R.id.progressBar);
        pb.setMax(no_of_questions);


        if (savedInstanceState != null) {
            q.setText(savedInstanceState.getString("question"));
            counter = savedInstanceState.getInt("counter");
            pb.setProgress(counter);
            bgColor = savedInstanceState.getInt("bgColor");
            q.setBackgroundColor(bgColor);
        }
        else{
            q.setText((Question[0]).split("\\|")[0]);
            Random rnd = new Random();
            bgColor = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            q.setBackgroundColor(bgColor);
        }

        True.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(counter<no_of_questions)
                {
                    if((Question[counter-1]).split("\\|")[1].equals(getString(R.string.F)))
                    {
                        Toast.makeText(MainActivity.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                        correct_answers++;
                    }

                    q.setText((Question[counter]).split("\\|")[0]);
                    counter++;
                    Random rnd = new Random();
                    bgColor = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                    q.setBackgroundColor(bgColor);
                    pb.setProgress(counter);
                }
                else
                {
                    show_save_dialog();
                    List<String> list = Arrays.asList(Question);
                    Collections.shuffle(list);
                    Question=list.toArray(new String[0]);
                    counter=1;
                    pb.setProgress(0);
                    q.setText(Question[0].split("\\|")[0]);
                    correct_answers=0;

                }
            }


        });

        False.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (counter < no_of_questions) {

                    if((Question[counter-1]).split("\\|")[1].equals(getString(R.string.T)))
                    {
                        Toast.makeText(MainActivity.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                        correct_answers++;
                    }

                    q.setText((Question[counter]).split("\\|")[0]);
                    counter++;
                    Random rnd = new Random();
                    bgColor = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                    q.setBackgroundColor(bgColor);
                    pb.setProgress(counter);
                }
                else
                {
                    show_save_dialog();
                    List<String> list = Arrays.asList(Question);
                    Collections.shuffle(list);
                    Question=list.toArray(new String[0]);
                    counter=1;
                    pb.setProgress(0);
                    q.setText(Question[0].split("\\|")[0]);
                    correct_answers=0;
                }

            }
        });

    }


    private void show_save_dialog()
    {
        int total_questions = no_of_questions;
        String message = "Your score is " + correct_answers + " out of " + total_questions + " correct answers.";
        int c=correct_answers;
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Result");
        builder.setMessage(message);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    int tq=total_questions+total_previous_q;
                    int ta=c+total_previous_a;
                    FileOutputStream fileOutputStream = openFileOutput("Result.txt", MODE_PRIVATE);
                    String result = (tq + "|" + ta);
                    fileOutputStream.write(result.getBytes());
                    fileOutputStream.close();
                    Toast.makeText(MainActivity.this, "Results saved", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("Ignore", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    private void readfile()
    {
        try {
            FileInputStream fis = openFileInput("Result.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String line = br.readLine();
            total_previous_a=Integer.parseInt(line.split("\\|")[1]);
            total_previous_q=Integer.parseInt(line.split("\\|")[0]);
            br.close();
        }catch (IOException e) {
            Toast.makeText(MainActivity.this, "Results saved", Toast.LENGTH_LONG).show();
        }
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.average:
                readfile();
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Your correct answers/Total questions=\n"+total_previous_a+"/"+total_previous_q);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
                builder.create().show();
                break;
            case R.id.no_questions:
                builder = new AlertDialog.Builder(this);
                builder.setTitle("Enter a number less than "+number_of_questions);
                final EditText input = new EditText(this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                builder.setView(input);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String userInput = input.getText().toString();

                        try {
                            int number = Integer.parseInt(userInput);
                            if(number<number_of_questions&&number>0) {

                                List<String> list = Arrays.asList(Question);
                                Collections.shuffle(list);
                                Question=list.toArray(new String[0]);
                                counter=1;
                                no_of_questions=number;
                                pb.setMax(number);
                                pb.setProgress(0);
                                q.setText(Question[0]);
                                correct_answers=0;
                            }
                            else
                            {
                                Toast.makeText(MainActivity.this, "Invalid number", Toast.LENGTH_SHORT).show();
                            }
                        } catch (NumberFormatException e) {

                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;
            case R.id.reset:

                try {
                    FileOutputStream fileOutputStream = openFileOutput("Result.txt", MODE_PRIVATE);
                    String result = (0 + "|" + 0);
                    fileOutputStream.write(result.getBytes());
                    fileOutputStream.close();
                    Toast.makeText(MainActivity.this, "Results saved", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;

        }
        return false;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("question", q.getText().toString());
        outState.putInt("counter", counter);
        outState.putInt("bgColor", bgColor);
    }


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        q.setText(savedInstanceState.getString("question"));
        counter = savedInstanceState.getInt("counter");
        pb.setProgress(counter);
        bgColor = savedInstanceState.getInt("bgColor");
        q.setBackgroundColor(bgColor);
    }

}
