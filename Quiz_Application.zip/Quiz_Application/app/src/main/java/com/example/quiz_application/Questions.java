package com.example.quiz_application;

public class Questions {

    public String[] Question = new String[]
            {
                    "The capital of Japan is Tokyo.|True",
                    "The capital of Canada is Vancouver.|False",
                    "The capital of Russia is Moscow.|True",
                    "The capital of Brazil is Rio de Janeiro.|False",
                    "The capital of Egypt is Cairo.|True",
                    "The capital of Australia is Melbourne.|False",
                    "The capital of Spain is Madrid.|True",
                    "The capital of South Africa is Johannesburg.|False",
                    "The capital of Italy is Rome.|True",
                    "The capital of China is Shanghai.|False",
            };
    public int number_of_questions=Question.length;
}
